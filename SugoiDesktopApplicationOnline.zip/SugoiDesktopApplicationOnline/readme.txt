Read me

Please ensure that the the following is in the folder:

Folder lib
File SugoiDesktopApplicationOffline.jar
File proxy.txt

Please fill in network proxy settings next to the respective property "=" in the proxy.txt file.
Do not edit the file if there are no proxy settings.

and run the Jar file from this folder. Do not move it out of this folder because it has
dependencies on other input files and libraries within this folder.

SUGOI! URL http://www.thezfiles.co.za/ROMULUS/ontologyInterchange.html